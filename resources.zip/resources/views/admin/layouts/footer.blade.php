
<div class="text-center">
    <span class="text-muted">Copyright © {{ date('Y') }} - All rights reserved.</span>
</div>
