<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;

class BrandController extends Model
{
    //
}
